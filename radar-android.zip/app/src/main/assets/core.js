// Lógica comum da busca (usada pelo fundo da extensão e pela página do Radar).
const DEFAULTS = { minPrice: 800000, maxPrice: 850000, autoMinutes: 30, notifyDivisa: false };
let running = false;

async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return { ...DEFAULTS, ...(settings || {}) };
}

async function scheduleAlarm() {
  const s = await getSettings();
  await chrome.alarms.clear('scan');
  if (s.autoMinutes > 0) chrome.alarms.create('scan', { periodInMinutes: s.autoMinutes, delayInMinutes: 1 });
}

function status(state, text) {
  chrome.storage.local.set({ status: { state, text, at: Date.now() } });
}

// Faz a busca e guarda o resultado. doScan(params) devolve { items, errors, complete, extraDates }.
async function runScanCore(doScan, onProgress) {
  if (running) return { busy: true };
  running = true;
  status('running', 'Buscando…');
  try {
    const settings = await getSettings();
    const SCHEMA = 3; // muda quando a forma de guardar os anúncios muda: força uma busca completa
    const store = await chrome.storage.local.get(['items', 'baselineAt', 'lastFullScan', 'rangeKey', 'schema']);
    const rangeKey = settings.minPrice + '-' + settings.maxPrice;
    const items = store.items || {};
    const baseline = !store.baselineAt;
    // modo rápido: para quando chega em anúncios já conhecidos. Uma busca completa a cada 6 h
    // (ou quando a faixa de preço muda) atualiza preços e marca os que saíram do ar.
    const quick = !baseline && store.schema === SCHEMA && store.rangeKey === rangeKey && Date.now() - (store.lastFullScan || 0) < 6 * 3600e3;
    const res = await doScan({ minPrice: settings.minPrice, maxPrice: settings.maxPrice, known: Object.keys(items), quick, dated: Object.keys(items).filter(k => items[k].pubAt),
      undated: Object.values(items).filter(it => it.src === 'ZAP' && !it.pubAt && !it.gone).map(({ key, url, rua, title }) => ({ key, url, rua, title })) });
    if (!res || !Array.isArray(res.items)) throw new Error('A busca não respondeu. Clique em Atualizar de novo.');
    for (const [k, d] of Object.entries(res.extraDates || {})) if (items[k]) Object.assign(items[k], d);
    const now = Date.now();
    const okSources = new Set(quick ? [] : (res.complete || []));
    const fresh = [];
    const seenNow = new Set();
    for (const it of res.items) {
      if (it.price < settings.minPrice || it.price > settings.maxPrice) continue;
      seenNow.add(it.key);
      it.posto = classify(it);
      const old = items[it.key];
      if (!old) {
        items[it.key] = { ...it, firstSeen: now, lastSeen: now, baseline };
        if (!baseline) fresh.push(items[it.key]);
      } else {
        const prevPrice = it.price < old.price ? old.price : old.prevPrice;
        items[it.key] = { ...old, ...it, prevPrice, firstSeen: old.firstSeen, baseline: old.baseline, lastSeen: now, gone: false };
      }
    }
    for (const k in items) {
      const it = items[k];
      if (!seenNow.has(k) && okSources.has(it.src)) {
        if (!it.gone) it.gone = now;
        if (now - it.gone > 14 * 864e5) delete items[k];
      }
    }
    await chrome.storage.local.set({ items, lastScan: now, lastErrors: res.errors, rangeKey, ...(quick ? {} : { lastFullScan: now, schema: SCHEMA }), ...(baseline ? { baselineAt: now } : {}) });

    const notifyList = fresh.filter(it => isTarget(it.posto) || (settings.notifyDivisa && it.posto === 'Divisa 4/5'));
    if (notifyList.length) {
      const first = notifyList[0];
      chrome.notifications.create('radar-' + now, {
        type: 'basic', iconUrl: 'icon128.png', priority: 2,
        title: notifyList.length === 1 ? 'Novo apartamento no ' + first.posto : `${notifyList.length} novos apartamentos no Posto 5/6`,
        message: notifyList.slice(0, 3).map(it => `${it.src} · R$ ${it.price.toLocaleString('pt-BR')} · ${it.m2} m² · ${it.rua || it.posto}`).join('\n')
      });
    }
    chrome.action.setBadgeBackgroundColor({ color: '#15803d' });
    const unseen = Object.values(items).filter(it => it.price >= settings.minPrice && it.price <= settings.maxPrice && !it.baseline && !it.viewed && isTarget(it.posto) && !it.gone).length;
    chrome.action.setBadgeText({ text: unseen ? String(unseen) : '' });

    const msg = `${quick ? 'Busca rápida' : 'Busca completa'}: ${res.items.length} anúncios lidos, ${fresh.length} novos` + (res.errors.length ? ' (com erro em parte da busca)' : '');
    status(res.errors.length && !res.items.length ? 'error' : 'ok', msg);
    return { ok: true, fresh: fresh.length, errors: res.errors };
  } catch (e) {
    status('error', e.message);
    return { ok: false, error: e.message };
  } finally {
    running = false;
  }
}

