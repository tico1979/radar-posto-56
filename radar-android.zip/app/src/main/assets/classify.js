// Em que posto fica o anúncio, pela rua (ZAP) ou pelo título (OLX).
const RE_56 = /S[aá] Ferreira/i;
const RE_5 = /Miguel Lemos|Bol[ií]var|Dias da Rocha|Xavier da Silveira|Aires Saldanha|Djalma Ulrich|Leopoldo Miguez|Edmundo Lins|posto ?5\b|posto cinco/i;
const RE_6 = /Souza Lima|Raul Pomp[eé]ia|Conselheiro Lafa|Rainha Elizabeth|Francisco S[aá]\b|J[uú]lio de Castilho|Gomes Carneiro|Bulh[oõ]es de Carvalho|Francisco Otaviano|Joaquim Nabuco|Almirante Gon[cç]alves|Saint Roman|Arpoador|posto ?6\b|posto seis|Forte de Copa/i;
const RE_DIV = /Bar[aã]o de Ipanema|Pompeu Loureiro/i;

function classify(item) {
  const text = `${item.rua || ''} ${item.title || ''}`;
  if (RE_56.test(text)) return 'Posto 5/6';
  if (RE_5.test(text)) return 'Posto 5';
  if (RE_6.test(text)) return 'Posto 6';
  if (RE_DIV.test(text)) return 'Divisa 4/5';
  return '';
}
const isTarget = p => p === 'Posto 5' || p === 'Posto 6' || p === 'Posto 5/6';
