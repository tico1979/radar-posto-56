package br.radar.posto56;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;

/** Busca automática em segundo plano: roda o mesmo leitor da tela numa página invisível. */
public class RadarJob extends JobService {
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private JobParameters params;

    @Override
    public boolean onStartJob(JobParameters p) {
        params = p;
        try {
            web = new WebView(getApplicationContext());
            Bridge.setup(web, this, () -> main.post(this::finish));
            web.loadUrl("file:///android_asset/bg.html");
            main.postDelayed(this::finish, 4 * 60 * 1000);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private void finish() {
        if (web != null) {
            web.destroy();
            web = null;
            jobFinished(params, false);
        }
    }

    @Override
    public boolean onStopJob(JobParameters p) {
        if (web != null) {
            web.destroy();
            web = null;
        }
        return true;
    }
}
