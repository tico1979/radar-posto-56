package br.radar.posto56;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

import org.json.JSONObject;

/** Agenda a busca automática conforme a configuração "Buscar sozinho". */
public class Scheduler {
    private static final int JOB_ID = 56;

    static void schedule(Context ctx, boolean force) {
        JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        int minutes = autoMinutes(ctx);
        if (minutes <= 0) {
            js.cancel(JOB_ID);
            return;
        }
        long interval = Math.max(15, minutes) * 60_000L;
        JobInfo current = js.getPendingJob(JOB_ID);
        if (!force && current != null && current.getIntervalMillis() == interval) return;
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(ctx, RadarJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(interval)
                .setPersisted(true)
                .build();
        js.schedule(job);
    }

    private static int autoMinutes(Context ctx) {
        String s = ctx.getSharedPreferences("radar", Context.MODE_PRIVATE).getString("settings", null);
        if (s == null) return 30;
        try {
            return new JSONObject(s).optInt("autoMinutes", 30);
        } catch (Exception e) {
            return 30;
        }
    }
}
