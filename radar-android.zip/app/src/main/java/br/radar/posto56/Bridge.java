package br.radar.posto56;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** Ponte entre a página (JavaScript) e o Android: dados guardados, busca na internet e notificações. */
public class Bridge {
    private static final String UA =
            "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36";

    private final Context ctx;
    private final Runnable onDone;
    private final SharedPreferences prefs;
    private final ExecutorService pool = Executors.newFixedThreadPool(8);
    private final ConcurrentHashMap<Integer, String> results = new ConcurrentHashMap<>();
    private final AtomicInteger seq = new AtomicInteger();

    Bridge(Context ctx, Runnable onDone) {
        this.ctx = ctx.getApplicationContext();
        this.onDone = onDone;
        this.prefs = this.ctx.getSharedPreferences("radar", Context.MODE_PRIVATE);
    }

    static void setup(WebView web, Context ctx, Runnable onDone) {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(ctx, onDone), "Android");
    }

    @JavascriptInterface
    public String get(String key) {
        return prefs.getString(key, null);
    }

    @JavascriptInterface
    public void set(String key, String json) {
        prefs.edit().putString(key, json).apply();
    }

    @JavascriptInterface
    public int fetchStart(final String url) {
        final int id = seq.incrementAndGet();
        pool.execute(() -> results.put(id, download(url)));
        return id;
    }

    /** Devolve "código\ncorpo" quando terminou, ou null enquanto ainda está baixando. */
    @JavascriptInterface
    public String fetchResult(int id) {
        return results.remove(id);
    }

    @JavascriptInterface
    public void notify(String title, String message) {
        Notifier.show(ctx, title, message);
    }

    @JavascriptInterface
    public void reschedule() {
        Scheduler.schedule(ctx, true);
    }

    @JavascriptInterface
    public void done() {
        if (onDone != null) onDone.run();
    }

    private static String download(String address) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(20000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
            c.setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9");
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String body = "";
            if (in != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                body = new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
            return code + "\n" + body;
        } catch (Exception e) {
            return "0\n" + e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
